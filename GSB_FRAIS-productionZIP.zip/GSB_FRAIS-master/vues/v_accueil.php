﻿<div id="accueil" class="jumbotron">
Bienvenue <?php echo $_SESSION['nom'] .' '. $_SESSION['prenom']; ?>
</div>
